const path         = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") });
const express      = require("express");
const cors         = require("cors");
const helmet       = require("helmet");
const errorHandler = require("./middlewares/errorHandler");
const { apiLimiter } = require("./middlewares/rateLimiter");

const authRoutes    = require("./routes/authRoutes");
const productRoutes = require("./routes/productRoutes");
const orderRoutes   = require("./routes/orderRoutes");
const cartRoutes    = require("./routes/cartRoutes");
const adminRoutes   = require("./routes/adminRoutes");
const paymentRoutes = require("./routes/paymentRoutes");

const app = express();

// ── Security ──────────────────────────────────────────────
app.use(helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" } // allow serving uploads
}));
app.use(cors({
    origin:      process.env.FRONTEND_URL || "http://localhost:5173",
    credentials: true
}));

// ── Global rate limiter ───────────────────────────────────
app.use("/api", apiLimiter);

// ── Body parsers ──────────────────────────────────────────
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// ── Static served uploads ─────────────────────────────────
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ── API Routes ────────────────────────────────────────────
app.use("/api/auth",     authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders",   orderRoutes);
app.use("/api/cart",     cartRoutes);
app.use("/api/admin",    adminRoutes);
app.use("/api/payments", paymentRoutes);

// ── Health check ──────────────────────────────────────────
app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "🌾 AgriMart API v2.0 running" });
});

// ── 404 ───────────────────────────────────────────────────
app.use((req, res) => {
    res.status(404).json({ message: "Route not found" });
});

// ── Centralized error handler (MUST be last) ──────────────
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 AgriMart server listening on http://localhost:${PORT}`);
});
