const { verifyToken } = require("../utils/jwt");

/**
 * Verify JWT from Authorization header.
 * Attaches req.userId and req.user (decoded payload).
 */
exports.verifyToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ message: "Unauthorized: no token provided" });
    }
    const token = authHeader.split(" ")[1];
    try {
        const decoded = verifyToken(token);
        if (!decoded || !decoded.id) {
            return res.status(401).json({ message: "Invalid or expired token" });
        }
        req.userId = decoded.id;
        req.user = decoded;
        next();
    } catch (err) {
        return res.status(401).json({ message: "Invalid or expired token" });
    }
};

/**
 * Allow only admin role.
 */
exports.requireAdmin = (req, res, next) => {
    if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Forbidden: admin access only" });
    }
    next();
};

/**
 * Allow admin or seller role.
 */
exports.requireSellerOrAdmin = (req, res, next) => {
    if (!req.user || !["seller", "admin"].includes(req.user.role)) {
        return res.status(403).json({ message: "Forbidden: seller or admin access only" });
    }
    next();
};