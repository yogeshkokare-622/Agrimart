const db = require("../config/db");

const ProductModel = {
    async create({ name, description, price, quantity, category, seller_id, image }) {
        try {
            const [result] = await db.query(
                `INSERT INTO products (name, description, price, quantity, category, seller_id, image)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [name, description, price, quantity, category || "General", seller_id, image || null]
            );
            return result.insertId;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Products table missing - skip create');
                return 999; // Fake ID for fallback
            }
            throw err;
        }
    },

    async getAll({ search = "", category = "" } = {}) {
        try {
            let sql = "SELECT p.*, u.name AS seller_name FROM products p JOIN users u ON p.seller_id = u.id WHERE 1=1";
            const params = [];
            if (search) {
                sql += " AND p.name LIKE ?";
                params.push(`%${search}%`);
            }
            if (category) {
                sql += " AND p.category = ?";
                params.push(category);
            }
            sql += " ORDER BY p.id DESC";
            const [rows] = await db.query(sql, params);
            return rows;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Products table missing - empty list');
                return [];
            }
            throw err;
        }
    },

    async findById(id) {
        try {
            const [rows] = await db.query(
                "SELECT p.*, u.name AS seller_name FROM products p JOIN users u ON p.seller_id = u.id WHERE p.id = ?",
                [id]
            );
            return rows[0] || null;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Product table missing - product not found');
                return null;
            }
            throw err;
        }
    },

    async getBySeller(seller_id) {
        try {
            const [rows] = await db.query(
                "SELECT * FROM products WHERE seller_id = ? ORDER BY id DESC",
                [seller_id]
            );
            return rows;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Seller products table missing - empty');
                return [];
            }
            throw err;
        }
    },

    async update(id, fields) {
        const allowed = ["name", "description", "price", "quantity", "category", "image"];
        const updates = [];
        const params = [];
        for (const key of allowed) {
            if (fields[key] !== undefined) {
                updates.push(`${key} = ?`);
                params.push(fields[key]);
            }
        }
        if (!updates.length) throw { status: 400, message: "No valid fields to update" };
        params.push(id);
        try {
            await db.query(`UPDATE products SET ${updates.join(", ")} WHERE id = ?`, params);
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Products table missing - skip update');
                return;
            }
            throw err;
        }
    },

    async delete(id) {
        try {
            await db.query("DELETE FROM products WHERE id = ?", [id]);
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Products table missing - skip delete');
                return;
            }
            throw err;
        }
    },

    async decrementQuantity(id, qty) {
        try {
            await db.query(
                "UPDATE products SET quantity = quantity - ? WHERE id = ? AND quantity >= ?",
                [qty, id, qty]
            );
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Products table missing - skip decrement');
                return;
            }
            throw err;
        }
    },

    async getCategories() {
        try {
            const [rows] = await db.query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL ORDER BY category");
            return rows.map(r => r.category);
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📦 Categories table missing - empty');
                return [];
            }
            throw err;
        }
    }
};

module.exports = ProductModel;

