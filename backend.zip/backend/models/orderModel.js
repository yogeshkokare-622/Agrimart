const db = require("../config/db");

const OrderModel = {

    // ✅ CREATE ORDER (FIXED)
    async create({ product_id, buyer_id, seller_id, quantity, total_price }) {
        try {
            // ✅ Insert order
            const [result] = await db.query(
                `INSERT INTO orders (product_id, buyer_id, seller_id, quantity, total_price, status)
                 VALUES (?, ?, ?, ?, ?, 'Pending')`,
                [product_id, buyer_id, seller_id, quantity, total_price]
            );

            return result.insertId;

        } catch (err) {
            console.error("❌ DB ORDER CREATE ERROR:", err.message || err);
            throw err;
        }
    },

    // ✅ GET ORDERS BY BUYER
    async getByBuyer(buyer_id) {
        try {
            const [rows] = await db.query(
                `SELECT o.id, o.quantity, o.total_price, o.status, o.created_at,
                        p.name AS product_name, p.description AS product_description,
                        p.price AS product_price, p.image AS product_image,
                        u.name AS seller_name, u.email AS seller_email
                 FROM orders o
                 JOIN products p ON o.product_id = p.id
                 JOIN users u    ON o.seller_id  = u.id
                 WHERE o.buyer_id = ?
                 ORDER BY o.id DESC`,
                [buyer_id]
            );
            return rows;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📝 Orders table missing - empty orders');
                return [];
            }
            throw err;
        }
    },

    // ✅ GET ORDERS BY SELLER
    async getBySeller(seller_id) {
        try {
            const [rows] = await db.query(
                `SELECT o.id, o.quantity, o.total_price, o.status, o.created_at,
                        p.name AS product_name, p.image AS product_image,
                        u.name AS buyer_name, u.email AS buyer_email, u.phone AS buyer_phone
                 FROM orders o
                 JOIN products p ON o.product_id = p.id
                 JOIN users u    ON o.buyer_id   = u.id
                 WHERE o.seller_id = ?
                 ORDER BY o.id DESC`,
                [seller_id]
            );
            return rows;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📝 Seller orders table missing - empty');
                return [];
            }
            throw err;
        }
    },

    // ✅ GET ALL ORDERS (ADMIN)
    async getAll() {
        try {
            const [rows] = await db.query(
                `SELECT o.id, o.quantity, o.total_price, o.status, o.created_at,
                        p.name AS product_name,
                        buyer.name  AS buyer_name,  buyer.email  AS buyer_email,
                        seller.name AS seller_name, seller.email AS seller_email
                 FROM orders o
                 JOIN products p ON o.product_id  = p.id
                 JOIN users buyer  ON o.buyer_id  = buyer.id
                 JOIN users seller ON o.seller_id = seller.id
                 ORDER BY o.id DESC`
            );
            return rows;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📝 All orders table missing - empty');
                return [];
            }
            throw err;
        }
    },

    // ✅ UPDATE ORDER STATUS
    async updateStatus(id, status) {
        try {
            await db.query(
                "UPDATE orders SET status = ? WHERE id = ?",
                [status, id]
            );
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('📝 Orders table missing - skip update');
                return;
            }
            throw err;
        }
    },

    // ✅ FIND ORDER BY ID
    async findById(id) {
        try {
            const [rows] = await db.query(
                "SELECT * FROM orders WHERE id = ?",
                [id]
            );
            return rows[0] || null;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                return null;
            }
            throw err;
        }
    }
};

module.exports = OrderModel;