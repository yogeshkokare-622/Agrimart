const db = require("../config/db");

const CartModel = {
    async addOrUpdate({ user_id, product_id, quantity }) {
        try {
            // INSERT or increment if already exists
            await db.query(
                `INSERT INTO cart (user_id, product_id, quantity)
                 VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)`,
                [user_id, product_id, quantity]
            );
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('🛒 Cart table missing - skip add');
                return;
            }
            throw err;
        }
    },

    async setQuantity({ user_id, product_id, quantity }) {
        try {
            await db.query(
                `INSERT INTO cart (user_id, product_id, quantity)
                 VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE quantity = VALUES(quantity)`,
                [user_id, product_id, quantity]
            );
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('🛒 Cart table missing - skip setQuantity');
                return;
            }
            throw err;
        }
    },

    async getByUser(user_id) {
        try {
            const [rows] = await db.query(
                `SELECT c.id, c.quantity, c.created_at,
                        p.id AS product_id, p.name, p.description, p.price, p.image, p.quantity AS stock
                 FROM cart c
                 JOIN products p ON c.product_id = p.id
                 WHERE c.user_id = ?
                 ORDER BY c.id DESC`,
                [user_id]
            );
            return rows;
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('🛒 Cart table missing - empty cart');
                return [];
            }
            throw err;
        }
    },

    async removeItem({ user_id, product_id }) {
        try {
            await db.query(
                "DELETE FROM cart WHERE user_id = ? AND product_id = ?",
                [user_id, product_id]
            );
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('🛒 Cart table missing - skip remove');
                return;
            }
            throw err;
        }
    },

    async clearCart(user_id) {
        try {
            await db.query("DELETE FROM cart WHERE user_id = ?", [user_id]);
        } catch (err) {
            if (err.code === 'ER_NO_SUCH_TABLE') {
                console.log('🛒 Cart table missing - skip clear');
                return;
            }
            throw err;
        }
    }
};

module.exports = CartModel;
