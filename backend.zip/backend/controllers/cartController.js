const CartService = require("../services/cartService");

exports.getCart = async (req, res, next) => {
    console.log('🛒 CART GET - userId:', req.userId);
    try {
        const cart = await CartService.getCart(req.userId);
        console.log('✅ CART SUCCESS:', cart.items?.length || 0);
        res.json(cart);
    } catch (err) {
        console.error('❌ CART ERROR:', err.message, err.code || err.sqlState);
        // Fallback for DB unavailable - empty cart
        if (err.code && (err.code.startsWith('ER_') || err.sqlState)) {
            console.log('🔄 CART FALLBACK empty');
            return res.json({ items: [], total: '0.00' });
        }
        next(err);
    }
};

exports.addToCart = async (req, res, next) => {
    try {
        const { product_id, quantity } = req.body;
        const result = await CartService.addToCart({ user_id: req.userId, product_id, quantity });
        res.status(201).json(result);
    } catch (err) {
        next(err);
    }
};

exports.updateCartItem = async (req, res, next) => {
    try {
        const { quantity } = req.body;
        const product_id = req.params.productId;
        const result = await CartService.updateCartItem({ user_id: req.userId, product_id, quantity });
        res.json(result);
    } catch (err) {
        next(err);
    }
};

exports.removeFromCart = async (req, res, next) => {
    try {
        const product_id = req.params.productId;
        const result = await CartService.removeFromCart({ user_id: req.userId, product_id });
        res.json(result);
    } catch (err) {
        next(err);
    }
};

exports.clearCart = async (req, res, next) => {
    try {
        const result = await CartService.clearCart(req.userId);
        res.json(result);
    } catch (err) {
        next(err);
    }
};
