const OrderService = require("../services/orderService");

exports.createOrder = async (req, res, next) => {
    if (global.dbError) {
        return res.status(503).json({ success: false, message: "Database connection failed" });
    }
    try {
        const { product_id, quantity } = req.body;
        const buyer_id = req.userId;

        if (!buyer_id) return res.status(401).json({ success: false, message: "Unauthorized" });
        if (!product_id) return res.status(400).json({ success: false, message: "Product ID is required" });
        if (!quantity || quantity <= 0) return res.status(400).json({ success: false, message: "Valid quantity is required" });

        const result = await OrderService.placeOrder({ product_id, quantity, buyer_id });
        return res.status(201).json({ success: true, ...result });

    } catch (err) {
        console.error('❌ ORDER CREATE ERROR:', err);
        next(err);
    }
};

exports.getOrders = async (req, res, next) => {
    if (global.dbError) {
        return res.status(503).json({ success: false, message: "Database connection failed" });
    }
    try {
        if (!req.userId) return res.status(401).json({ success: false, message: "Unauthorized" });
        const orders = await OrderService.getMyOrders(req.userId);
        return res.json(orders || []);
    } catch (err) {
        console.error('❌ GET ORDERS ERROR:', err);
        next(err);
    }
};

exports.getSellerOrders = async (req, res, next) => {
    if (global.dbError) {
        return res.status(503).json({ success: false, message: "Database connection failed" });
    }
    try {
        if (!req.userId) return res.status(401).json({ success: false, message: "Unauthorized" });
        const orders = await OrderService.getSellerOrders(req.userId);
        return res.json(orders || []);
    } catch (err) {
        console.error('❌ GET SELLER ORDERS ERROR:', err);
        next(err);
    }
};

exports.updateOrderStatus = async (req, res, next) => {
    if (global.dbError) {
        return res.status(503).json({ success: false, message: "Database connection failed" });
    }
    try {
        const { status } = req.body;
        if (!status) return res.status(400).json({ success: false, message: "Status is required" });

        const result = await OrderService.updateOrderStatus(
            req.params.id,
            status,
            req.userId,
            req.user?.role
        );
        return res.json(result);
    } catch (err) {
        console.error('❌ UPDATE STATUS ERROR:', err);
        next(err);
    }
};

exports.getAllOrders = async (req, res, next) => {
    if (global.dbError) {
        return res.status(503).json({ success: false, message: "Database connection failed" });
    }
    try {
        const orders = await OrderService.getAllOrders();
        return res.json(orders || []);
    } catch (err) {
        console.error('❌ GET ALL ORDERS ERROR:', err);
        next(err);
    }
};