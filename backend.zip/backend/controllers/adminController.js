const UserModel  = require("../models/userModel");
const OrderModel = require("../models/orderModel");
const db         = require("../config/db");

exports.getAllUsers = async (req, res, next) => {
    try {
        const users = await UserModel.getAll();
        res.json(users);
    } catch (err) {
        next(err);
    }
};

exports.getAllOrders = async (req, res, next) => {
    try {
        const orders = await OrderModel.getAll();
        res.json(orders);
    } catch (err) {
        next(err);
    }
};

exports.getDashboardStats = async (req, res, next) => {
    try {
        const [[{ userCount }]]    = await db.query("SELECT COUNT(*) AS userCount FROM users");
        const [[{ productCount }]] = await db.query("SELECT COUNT(*) AS productCount FROM products");
        const [[{ orderCount }]]   = await db.query("SELECT COUNT(*) AS orderCount FROM orders");
        const [[{ revenue }]]      = await db.query("SELECT IFNULL(SUM(total_price), 0) AS revenue FROM orders WHERE status != 'Cancelled'");
        res.json({ userCount, productCount, orderCount, revenue });
    } catch (err) {
        next(err);
    }
};

exports.updateOrderStatus = async (req, res, next) => {
    try {
        const { status } = req.body;
        const allowed = ["Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"];
        if (!allowed.includes(status)) {
            return res.status(400).json({ message: "Invalid status" });
        }
        await OrderModel.updateStatus(req.params.id, status);
        res.json({ message: "Order status updated" });
    } catch (err) {
        next(err);
    }
};

exports.deleteUser = async (req, res, next) => {
    try {
        await db.query("DELETE FROM users WHERE id = ? AND role != 'admin'", [req.params.id]);
        res.json({ message: "User deleted" });
    } catch (err) {
        next(err);
    }
};
