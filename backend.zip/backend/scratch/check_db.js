const mysql = require("mysql2/promise");
require("dotenv").config({ path: "./.env" });

async function checkSchema() {
    const pool = mysql.createPool({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });
    try {
        const [rows] = await pool.query("DESCRIBE orders");
        console.log("COLUMNS IN 'orders' TABLE:");
        rows.forEach(r => console.log(`- ${r.Field} (${r.Type})`));
    } catch (err) {
        console.error("ERROR:", err.message);
    } finally {
        await pool.end();
    }
}

checkSchema();
