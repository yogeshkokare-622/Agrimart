const mysql = require("mysql2/promise");
require("dotenv").config({ path: "./.env" });

async function migrate() {
    const pool = mysql.createPool({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });
    
    try {
        console.log("🚀 Starting Database Migration: Fix 'orders' table...");
        
        // 1. Add product_id
        await pool.query("ALTER TABLE orders ADD COLUMN product_id INT NOT NULL AFTER id").catch(e => console.log("- product_id exists or failed"));
        
        // 2. Add seller_id
        await pool.query("ALTER TABLE orders ADD COLUMN seller_id INT NOT NULL AFTER buyer_id").catch(e => console.log("- seller_id exists or failed"));
        
        // 3. Add quantity
        await pool.query("ALTER TABLE orders ADD COLUMN quantity INT NOT NULL DEFAULT 1 AFTER seller_id").catch(e => console.log("- quantity exists or failed"));
        
        // 4. Add total_price
        await pool.query("ALTER TABLE orders ADD COLUMN total_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00 AFTER quantity").catch(e => console.log("- total_price exists or failed"));
        
        // 5. Add updated_at
        await pool.query("ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP").catch(e => console.log("- updated_at exists or failed"));
        
        // 6. Fix status column type if needed
        await pool.query("ALTER TABLE orders MODIFY COLUMN status ENUM('Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled') DEFAULT 'Pending'").catch(e => console.log("- status modify failed"));

        console.log("✅ Migration completed successfully!");
        
    } catch (err) {
        console.error("❌ MIGRATION ERROR:", err.message);
    } finally {
        await pool.end();
    }
}

migrate();
