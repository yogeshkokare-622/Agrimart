const bcrypt = require("bcrypt");
bcrypt.hash("test", 10)
    .then(hash => console.log("Success:", hash))
    .catch(err => console.error("Failure:", err));
