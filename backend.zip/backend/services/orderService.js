const ProductModel = require("../models/productModel");
const OrderModel = require("../models/orderModel");

const OrderService = {
    async placeOrder({ product_id, quantity, buyer_id }) {
        if (!buyer_id) {
            throw { status: 401, message: "Unauthorized" };
        }
        if (!product_id || !quantity) {
            throw { status: 400, message: "Product and quantity are required" };
        }
        const qty = parseInt(quantity, 10);
        if (isNaN(qty) || qty < 1) {
            throw { status: 400, message: "Quantity must be at least 1" };
        }

        const product = await ProductModel.findById(product_id);
        if (!product) throw { status: 404, message: "Product not found" };

        if (product.seller_id === buyer_id) {
            throw { status: 400, message: "You cannot buy your own product" };
        }

        if (product.quantity < qty) {
            throw { status: 400, message: `Only ${product.quantity} units available` };
        }

        const total_price = parseFloat(product.price) * qty;
        const orderId = await OrderModel.create({
            product_id,
            buyer_id,
            seller_id: product.seller_id,
            quantity: qty,
            total_price
        });

        await ProductModel.decrementQuantity(product_id, qty);

        return { message: "Order placed successfully", orderId };
    },

    async getMyOrders(buyer_id) {
        if (!buyer_id) {
            throw { status: 401, message: "Unauthorized" };
        }
        const orders = await OrderModel.getByBuyer(buyer_id);
        return Array.isArray(orders) ? orders : [];
    },

    async getSellerOrders(seller_id) {
        return OrderModel.getBySeller(seller_id);
    },

    async updateOrderStatus(orderId, status, userId, role) {
        const allowed = ["Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"];
        if (!allowed.includes(status)) {
            throw { status: 400, message: "Invalid status value" };
        }
        const order = await OrderModel.findById(orderId);
        if (!order) throw { status: 404, message: "Order not found" };
        if (order.seller_id !== userId && role !== "admin") {
            throw { status: 403, message: "Forbidden" };
        }
        await OrderModel.updateStatus(orderId, status);
        return { message: "Order status updated" };
    },

    async getAllOrders() {
        return OrderModel.getAll();
    }
};

module.exports = OrderService;
