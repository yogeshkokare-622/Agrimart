const CartModel    = require("../models/cartModel");
const ProductModel = require("../models/productModel");

const CartService = {
    async addToCart({ user_id, product_id, quantity = 1 }) {
        const qty = parseInt(quantity, 10);
        if (isNaN(qty) || qty < 1) {
            throw { status: 400, message: "Quantity must be at least 1" };
        }
        const product = await ProductModel.findById(product_id);
        if (!product) throw { status: 404, message: "Product not found" };
        if (product.quantity < qty) {
            throw { status: 400, message: `Only ${product.quantity} units available` };
        }
        await CartModel.addOrUpdate({ user_id, product_id, quantity: qty });
        return { message: "Added to cart" };
    },

    async updateCartItem({ user_id, product_id, quantity }) {
        const qty = parseInt(quantity, 10);
        if (isNaN(qty) || qty < 1) {
            throw { status: 400, message: "Quantity must be at least 1" };
        }
        await CartModel.setQuantity({ user_id, product_id, quantity: qty });
        return { message: "Cart updated" };
    },

    async removeFromCart({ user_id, product_id }) {
        await CartModel.removeItem({ user_id, product_id });
        return { message: "Removed from cart" };
    },

    async getCart(user_id) {
        const items = await CartModel.getByUser(user_id);
        const total = items.reduce((sum, i) => sum + parseFloat(i.price) * i.quantity, 0);
        return { items, total: total.toFixed(2) };
    },

    async clearCart(user_id) {
        await CartModel.clearCart(user_id);
        return { message: "Cart cleared" };
    }
};

module.exports = CartService;
