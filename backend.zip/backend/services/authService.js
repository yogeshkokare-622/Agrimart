const bcrypt = require("bcrypt");
const UserModel = require("../models/userModel");
const { signToken } = require("../utils/jwt");

const AuthService = {
    async register({ name, email, password, phone, address, role }) {
        const existing = await UserModel.findByEmail(email);
        if (existing) throw { status: 409, message: "Email already registered. Please use different email or login." };

        if (!name || !email || !password || !phone || !address) {
            throw { status: 400, message: "All fields are required" };
        }
        if (password.length < 6) {
            throw { status: 400, message: "Password must be at least 6 characters" };
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const id = await UserModel.create({ name, email, hashedPassword, phone, address, role });
        return { id, message: "User registered successfully" };
    },

    async login({ email, password }) {
        if (!email || !password) {
            throw { status: 400, message: "Email and password are required" };
        }

        const user = await UserModel.findByEmail(email);
        if (!user) throw { status: 401, message: "Invalid credentials" };

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) throw { status: 401, message: "Invalid credentials" };

        const token = signToken({ id: user.id, email: user.email, role: user.role });

        return {
            message: "Login successful",
            token,
            user: { id: user.id, name: user.name, email: user.email, role: user.role }
        };
    },

    async getProfile(userId) {
        const user = await UserModel.findById(userId);
        if (!user) throw { status: 404, message: "User not found" };
        return user;
    },

    async updateProfile(userId, fields) {
        const user = await UserModel.findById(userId);
        if (!user) throw { status: 404, message: "User not found" };

        const updates = {};
        if (fields.name) updates.name = fields.name;
        if (fields.phone) updates.phone = fields.phone;
        if (fields.address) updates.address = fields.address;

        if (Object.keys(updates).length === 0) {
            throw { status: 400, message: "No fields to update" };
        }

        await UserModel.update(userId, updates);
        const updated = await UserModel.findById(userId);
        return updated;
    }
};

module.exports = AuthService;
