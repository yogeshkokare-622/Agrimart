const mysql = require("mysql2/promise");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });

const pool = mysql.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASS,
    database: process.env.DB_NAME || "agrimart",
    waitForConnections: true,
    connectionLimit: 20,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000
});

// Test connection on startup
(async () => {
    try {
        const conn = await pool.getConnection();
        console.log("✅ MySQL Connected successfully to", process.env.DB_NAME);
        conn.release();
    } catch (err) {
        console.error("❌ MySQL Connection Error:");
        console.error("  Host:", process.env.DB_HOST);
        console.error("  User:", process.env.DB_USER);
        console.error("  Error:", err.message);
        global.dbError = err;
    }
})();

module.exports = pool;
