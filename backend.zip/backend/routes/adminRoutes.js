const express          = require("express");
const router           = express.Router();
const adminController  = require("../controllers/adminController");
const { verifyToken, requireAdmin } = require("../middlewares/authMiddleware");
const { updateStatusRules, validate } = require("../middlewares/validators");

// All admin routes require authentication + admin role
router.use(verifyToken, requireAdmin);

router.get("/stats",           adminController.getDashboardStats);
router.get("/users",           adminController.getAllUsers);
router.delete("/users/:id",    adminController.deleteUser);
router.get("/orders",          adminController.getAllOrders);
router.patch("/orders/:id/status", updateStatusRules, validate, adminController.updateOrderStatus);

module.exports = router;
