const express         = require("express");
const router          = express.Router();
const cartController  = require("../controllers/cartController");
const { verifyToken } = require("../middlewares/authMiddleware");
const { addToCartRules, updateCartRules, validate } = require("../middlewares/validators");

router.get("/",                          verifyToken, cartController.getCart);
router.post("/",                         verifyToken, addToCartRules, validate, cartController.addToCart);
router.put("/:productId",               verifyToken, updateCartRules, validate, cartController.updateCartItem);
router.delete("/:productId",            verifyToken, cartController.removeFromCart);
router.delete("/",                      verifyToken, cartController.clearCart);

module.exports = router;
